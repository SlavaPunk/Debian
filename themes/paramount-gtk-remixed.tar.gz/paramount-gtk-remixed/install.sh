#! /bin/bash

clear
echo -e "Вы хотите установить тему?"
echo -e "Чтобы установить тему, вам нужен root доступ!"
read -n 1 line

cp -r Paramount-Solid-gtk-XFWM4 /usr/share/themes
cp -r Paramount-Solid-gtk /usr/share/themes

echo "Готово!"
